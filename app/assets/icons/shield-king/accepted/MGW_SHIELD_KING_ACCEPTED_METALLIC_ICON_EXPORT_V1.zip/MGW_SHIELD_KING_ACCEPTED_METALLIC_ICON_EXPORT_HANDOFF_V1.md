# MGW Shield King Accepted Metallic Icon Export Handoff V1

STATUS: FINAL ACCEPTED VISUAL EXPORT / ISOLATED / NOT INTEGRATED

BASE FROZEN DESIGN SYSTEM SHA: `7918d249112bcbadde8c59d3015a16c39dc3d2e1`

This asset-only export does not modify the frozen Shield King Design System and does not integrate into staging/main/production.

Visual source: preserved final accepted Variant 1 boards. Simplified geometry-reference SVGs are not visual sources.

Exact unrecoverable accepted visuals:
- `surrender`: no separate accepted final metallic visual found; no replacement invented.
- additional forward/up/down arrows: no separately accepted metallic family found beyond Back; no replacement invented.

See `MANIFEST.json` for every asset SHA-256 and path.
