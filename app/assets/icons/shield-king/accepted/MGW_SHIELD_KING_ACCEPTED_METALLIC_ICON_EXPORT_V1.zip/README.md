# Shield King Final Accepted Metallic Icon Export V1

This package contains only recovered final accepted metallic visual assets.

- UI icons: 128×128 lossless WebP RGBA.
- Game icons: 384×512 lossless WebP RGBA.
- No simplified SVG geometry reference is used as final artwork.
- No new design was created during export.
- `surrender` and additional forward/up/down arrows are intentionally absent because no exact final accepted visuals could be recovered.
- `qa/` contains contact sheets only; they are not runtime assets.
